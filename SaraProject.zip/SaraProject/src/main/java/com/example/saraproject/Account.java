package com.example.saraproject;
import java.io.*;
import java.util.*;

public class Account {
    static HashMap<String, String> accounts = new HashMap<>();
    static String fileName = "all_logins.txt";
    static File info = new File(fileName);
    static BufferedWriter bf = null;

    public static void main(String[] args) throws IOException {
        info();
    }
    public static void info() throws IOException
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to Our Hotel!");
        System.out.println("Do you have an account with us (Yes or No)?");

        int valid_input = 0;
        do{
            String choice = input.nextLine().trim().toLowerCase();
            if (choice.equals("n") || choice.equals("no"))
            {
                //createAccount();
                valid_input = 1;
            }
            else if (choice.equals("y") || choice.equals("yes"))
            {
                //login();
                valid_input = 1;
            }
            else
            {
                System.out.println("Invalid input! Please try again");

            }
        }while(valid_input == 0);
    }

    public static void createAccount(String user, String password) throws IOException {
        accounts.put(user, password);
        try {
            bf = new BufferedWriter(new FileWriter(info, true));
            bf.append(user).append(":").append(password);
            bf.newLine();
            System.out.println("Account successfully created!");
            bf.flush();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try {
                bf.close();
            }
            catch (Exception ignored)
            {
            }
        }
        Order.showMainMenu();
    }


    protected static void login(String user, String password) throws IOException
    {

        try (BufferedReader reader = new BufferedReader(new FileReader(info)))
        {
            String line;
            boolean found = false;
            while ((line = reader.readLine()) != null){
                String[] parts = line.split(":");
                if (parts.length == 2 && parts[0].equals(user) && parts[1].equals(password)){
                    System.out.println("Hello, " + user + "!");
                    Order.showMainMenu(); // Show the main menu after successful login
                    found = true;
                    break;
                }
            }
            if (!found){
                System.out.println("Sorry, invalid username or password. Please enter a valid user name. ");
                //login();
            }
        }
    }

}