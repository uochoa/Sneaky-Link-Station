package com.example.saraproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {
    @FXML
    private Parent root;

    @FXML
    private Stage stage;
    @FXML
    private Scene scene;
    @FXML
    private Button CreateButton;
    @FXML
    private Button loginButton;
    @FXML
    private TextField userTxt;
    @FXML
    private TextField createUserTxt;
    @FXML
    private PasswordField passTxt;
    @FXML
    private PasswordField createPassTxt;

    @FXML
    private Label loginMessageLabel;
    @FXML
    private Label createMessageLabel;

    public void loginButtonOnAction(ActionEvent e) throws IOException {

        if(userTxt.getText().isBlank() == false && passTxt.getText().isBlank() == false){
            loginMessageLabel.setText("Loading");
            Account.login(userTxt.getText().toString(), passTxt.getText().toString());
            switchSceneMenu(e);

        }else{
            loginMessageLabel.setText("Please enter username and password");
        }

    }
    public void CreateButtonOnAction(ActionEvent e) throws IOException {

        if(createUserTxt.getText().isBlank() == false && createPassTxt.getText().isBlank() == false){

            Account.createAccount(createUserTxt.getText().toString(), createPassTxt.getText().toString());
            createMessageLabel.setText("Loading");
           //System.out.println("Account successfully created!");
            stage = (Stage) CreateButton.getScene().getWindow();
            stage.close();
            switchSceneMenu(e);


        }else{
            createMessageLabel.setText("Please enter username and password");
        }

    }

    public void switchSceneMenu(ActionEvent e) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Menu.fxml"));
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}