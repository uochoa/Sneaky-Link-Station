package com.example.saraproject;

import com.example.saraproject.Account;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Order {
    static int standard = 100;
    static int deluxe = 150;
    static int suite = 200;
    static int availableStandardRooms = 15;
    static int availableDeluxeRooms = 10;
    static int availableSuiteRooms = 5;
    static String room;
    static int day;
    static int roomNum;
    static String valid_name = "^[a-zA-Z]+ [a-zA-Z]+$";
    static String valid_phone_numer = "^\\d{10}$";
    static String valid_email =  "^[\\w!#$%&’*+/=?`{|}~^-]+(?:\\.[\\w!#$%&’*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
    static String valid_date = "^(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])-[0-9]{4}$";
    static Map<String,Reservation> reservationsMap = new HashMap<>();
    static List<Reservation> reservations = new ArrayList<>();
    static String reservationFile = "reservations.txt";

    private static final DateTimeFormatter DATE_PARSER = DateTimeFormatter.ofPattern("MM-dd-uuuu");
    public static void main(String[] args) throws IOException {
        opener();

    }

    public static void showMainMenu() throws IOException
    {

        Scanner input = new Scanner(System.in);
        System.out.println("\nSuccessful Login, Welcome!");
        System.out.println("Please select an option:");
        System.out.println("1. Make a Reservation");
        System.out.println("2. View Reservations");
        System.out.println("3. Cancel Reservation");
        System.out.println("4. Exit");
        int choice = input.nextInt();

        switch (choice)
        {
            case 1:
                opener();
                break;
            case 2:
                viewReservations();
                break;
            case 3:
                input.nextLine(); // Consume the newline character
                System.out.println("Enter the phone number associated with the reservation you want to cancel:");
                String phoneNumber = input.nextLine();
                cancelReservation(phoneNumber);
                break;

            case 4:
                System.out.println("Exiting. Have a nice day!");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid choice. Please choose again.");
                showMainMenu();
                break;
        }
    }

    public static void viewReservations()
    {
        System.out.println("Viewing Reservations:");
        try (BufferedReader reader = new BufferedReader(new FileReader(reservationFile)))
        {
            String line;
            while ((line = reader.readLine()) != null)
            {
                System.out.println(line);
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public static void cancelReservation(String phoneNumber)
    {
        phoneNumber = phoneNumber.replaceAll("\\s+", ""); // Remove spaces from the input

        System.out.println("Searching for reservation with phone number: " + phoneNumber);

        boolean found = false;
        List<String> updatedReservations = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(reservationFile)))
        {
            String line;
            while ((line = reader.readLine()) != null)
            {
                String reservationPhoneNumber = extractPhoneNumber(line);
                String cleanedReservationPhoneNumber = reservationPhoneNumber.replaceAll("[^\\d]", ""); // Clean the extracted phone number
                String firstTenDigits = cleanedReservationPhoneNumber.substring(0, Math.min(cleanedReservationPhoneNumber.length(), 10)); // Extract first 10 digits

                if (firstTenDigits.equals(phoneNumber))
                {
                    found = true;
                    System.out.println("Found matching reservation. Removing...");
                }
                else
                {
                    updatedReservations.add(line); // Add non-matching reservations to the updated list
                }

            }
        } catch (IOException e)
        {
            e.printStackTrace();
        }

        if (found)
        {
            // Write the updated reservations back to the file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(reservationFile)))
            {
                for (String reservation : updatedReservations)
                {
                    writer.write(reservation);
                    writer.write("\n");
                }
                System.out.println("Reservation canceled successfully.");
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
        else
        {
            System.out.println("No reservation found with the provided phone number.");
            found = false;
        }

    }




    public static void addReservation(String name, String number, String email, String date, String time, String payment, double total) {
        reservations.add(new Reservation(name, number, email, date, time, payment, total)); // Updated method call
        writeReservationsToFile();
    }



    public static void writeReservationsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(reservationFile, true))) {
            for (Reservation reservation : reservations) {
                writer.write(reservation.toString());
                writer.write("\n"); // Add a newline character after each reservation
            }
            System.out.println("Reservations written to file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void readReservationsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(reservationFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String phoneNumber = extractPhoneNumber(line); // Extract phone number
                Reservation reservation = Reservation.createReservationFromLine(line); // Use Reservation.createReservationFromLine
                reservationsMap.put(phoneNumber, reservation); // Store reservation in map
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }





    private static String extractPhoneNumber(String line) {
        String phoneNumber = line.substring(line.indexOf("Phone Number: ") + 14);
        phoneNumber = phoneNumber.replaceAll("[^\\d]", ""); // Remove non-digit characters
        return phoneNumber;
    }




    private static class Reservation {
        private String name;
        private String number;
        private String email;
        private String date;
        private String time;
        private String payment;
        private double total;


        public Reservation(String name, String number, String email, String date, String time, String payment, double total) {
            this.name = name;
            this.number = number;
            this.email = email;
            this.date = date;
            this.payment = payment;
            this.total = total;
        }

        public static Reservation fromString(String line) {
            String[] parts = line.split(", ");
            if (parts.length == 7) {
                String name = parts[0].substring(6);
                String phoneNumber = extractPhoneNumber(parts[1]);
                String email = parts[2].substring(7);
                String date = parts[3].substring(13);
                String time = parts[4].substring(3);
                String payment = parts[5].substring(14);
                double total = Double.parseDouble(parts[6].substring(8));

                return new Reservation(name, phoneNumber, email, date, time, payment, total);
            }
            return null; // Return null if parsing fails
        }
        public static Reservation createReservationFromLine(String line) {
            // Parse the line to extract reservation details
            String[] parts = line.split(", ");
            if (parts.length == 7) {
                String name = parts[0].substring(6);
                String phoneNumber = extractPhoneNumber(parts[1]);
                String email = parts[2].substring(7);
                String date = parts[3].substring(13);
                String time = parts[4].substring(3);
                String payment = parts[5].substring(14);
                double total = Double.parseDouble(parts[6].substring(8));

                return new Reservation(name, phoneNumber, email, date, time, payment, total);
            }
            return null; // Return null if parts length is not 7 or parsing fails
        }


        @Override
        public String toString() {
            return "Name: " + name + ", Phone Number: " + number + ", Email: " + email +
                    ", Check-in: " + date + " at " + time + ", Payment Type: " + payment + ", Total: $" + total;
        }


    }

    public static void opener()
    {
        System.out.println("We have several rooms available:\n (1)Standard $100/night\n " + "(2)Deluxe $150/night\n" +
                " (3)Suite $200/night\n Please enter the number you are interested in!");
        Scanner input = new Scanner(System.in);
        room = input.nextLine();

        int check_room = 0;
        do{
            if (room.equals("1"))
            {
                check_room = 1;
            } else if (room.equals("2"))
            {
                check_room = 1;
            } else if (room.equals("3"))
            {
                check_room = 1;
            }
            else
            {
                System.out.println("Sorry invalid entry");
                room = input.nextLine();
            }
        }while(check_room == 0);


        System.out.println("Enter the number of Rooms you want to reserve: ");
        roomNum = input.nextInt();
        System.out.println("Awesome, how many days would this be for?");
        day = input.nextInt();
        rooms(room, day, roomNum);
    }


    public static void rooms(String room, int day, int roomNum) {
        int standard = 100;
        int deluxe = 150;
        int suite = 200;
        String taxList = " This is including an 18% tax.";

        int total;
        if (room.equals("1")) {
            if (roomNum <= availableStandardRooms) {
                total = (standard * day * roomNum);
                double newTotal = (total * 0.18) + total;
                System.out.println("You have selected the Standard Room, for " + day + " day(s)!\n" +
                        "Your total would come out to $" + newTotal + taxList);
                closer(day, taxList, newTotal, "Standard", roomNum);
            } else {
                System.out.println("Sorry, we don't have enough available Standard rooms.");
                opener();
            }
        } else if (room.equals("2")) {
            if (roomNum <= availableDeluxeRooms) {
                total = (deluxe * day * roomNum);
                double newTotal = (total * 0.18) + total;
                System.out.println("You have selected the Deluxe Room, for " + day + " day(s)!\n" +
                        "Your total would come out to $" + newTotal + taxList);
                closer(day, taxList, newTotal, "Deluxe", roomNum);
            } else {
                System.out.println("Sorry, we don't have enough available Deluxe rooms.");
                opener();
            }
        } else if (room.equals("3")) {
            if (roomNum <= availableSuiteRooms) {
                total = (suite * day * roomNum);
                double newTotal = (total * 0.18) + total;
                System.out.println("You have selected the Suite Room, for " + day + " day(s)!\n" +
                        "Your total would come out to $" + newTotal + taxList);
                closer(day, taxList, newTotal, "Suite", roomNum);
            } else {
                System.out.println("Sorry, we don't have enough available Suite rooms.");
                opener();
            }
        } else {
            System.out.println("Sorry we did not quite get that, please try again");
        }
    }


    private static void closer(int day, String taxList, double newTotal, String roomType, int roomNum) {
        Scanner input = new Scanner(System.in);

        System.out.println("We will now need you to provide us with a set of information to help us finalize your " +
                "reservation.\nEnter your first and last name: ");
        String name = input.nextLine();
        validate_user_entry(valid_name, name);

        System.out.println("Enter Phone Number (provide only digits): ");
        String number = input.nextLine();
        validate_user_entry(valid_phone_numer, number);

        System.out.println("Enter email address: ");
        String email = input.nextLine();
        validate_user_entry(valid_email, email);

        System.out.println("What date would you like to check in (MM-DD-YYYY)?");
        String date = input.nextLine();
        validate_user_entry(valid_date, date);

        LocalDate today = LocalDate.now();
        LocalDate myDate = LocalDate.parse(date, DATE_PARSER);
        int check_date = 0;
        do {
            if (myDate.isBefore(today)) {
                System.out.println(date + " is in the past. Please enter a valid date");
                date = input.nextLine();
                myDate = LocalDate.parse(date, DATE_PARSER);
            } else if (myDate.isAfter(today)) {
                check_date = 1;
            } else {
                System.out.println(date + " is today. Please enter a date in the future");
                date = input.nextLine();
                myDate = LocalDate.parse(date, DATE_PARSER);
            }
        } while (check_date == 0);

        System.out.println("Would you like to pay cash or credit/debit?");
        String payment = input.next().trim().toLowerCase();

        System.out.println("Thank you " + name + " for your patience. Please confirm if the following statements are " +
                "true...\nName: " + name + "\nPhone Number: " + number + "\nEmail: " + email + "\nCheck in: " + date +
                "\nPayment type: " + payment + "\nIs this correct (Y or N)?");

        String correct = input.next().trim().toLowerCase();
        if (correct.equals("y") || correct.equals("yes")) {
            System.out.println("Awesome, your total comes out to $" + newTotal + taxList +
                    "\nPlease be ready to show your ID for verification at the front desk upon arrival! The check-in time " +
                    "is 2:00 pm. We will provide you with your room number after a successful check-in.\nSee you on " + date + "!");

            // Update available room count based on user reservation
            if (roomType.equals("Standard"))
            {
                availableStandardRooms -= roomNum;
            }
            else if (roomType.equals("Deluxe"))
            {
                availableDeluxeRooms -= roomNum;
            }
            else if (roomType.equals("Suite"))
            {
                availableSuiteRooms -= roomNum;
            }

            // Add reservation to the list
            addReservation(name, number, email, date, "2:00 pm", payment, newTotal);
        } else {
            System.out.println("Please try again");
            closer(day, taxList, newTotal, roomType, roomNum);
        }
    }


    public static void validate_user_entry(String regex, String user_entry)
    {
        int check = 0;
        Scanner input = new Scanner(System.in);

        do {


            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(user_entry);

            if (m.matches())
            {
                check = 1;
            }
            else
            {
                System.out.println("Invalid entry. Please re-enter.");
                user_entry = input.nextLine();
            }

        }while(check == 0);
    }

}