module com.example.saraproject {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.saraproject to javafx.fxml;
    exports com.example.saraproject;
}